# フォーム一覧

| 画面ID | フィールド名 | 型 | 必須 | placeholder |
|---|---|---|---|---|
| P004 | name | text | Yes | - |
| P004 | email | email | Yes | - |
| P004 | body | textarea | No | - |
| P005 | t | text | Yes | 英字 |
| P005 | n | number | No | - |
| P005 | d | date | No | - |
| P005 | s | select | No | - |
| P005 | r | radio | No | - |
| P005 | r | radio | No | - |
| P005 | c | checkbox | No | - |
| P005 | tel | tel | No | - |
| P005 | csrf | hidden | No | - |
| P005 | f | file | No | - |
