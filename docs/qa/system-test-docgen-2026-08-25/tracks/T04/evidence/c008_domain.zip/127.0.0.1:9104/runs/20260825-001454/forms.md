# フォーム一覧

| 画面ID | フィールド名 | 型 | 必須 | placeholder |
|---|---|---|---|---|
| P003 | name | text | Yes | - |
| P003 | email | email | Yes | - |
| P003 | body | textarea | No | - |
